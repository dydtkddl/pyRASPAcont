# pyRASPAcont-v01
Control RASPA simulation with python


```python
import pydircont as pct
pct.killlall()
```


