from pyrascont import *

cpu_percent = cpucheck()

print(cpu_percent)

