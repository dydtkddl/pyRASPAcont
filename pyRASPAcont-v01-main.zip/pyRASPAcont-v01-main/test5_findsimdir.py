from pyrascont import *

prefix = 'sim_no'
dir_list = findsimdir(prefix)
print(dir_list)
