from pyrascont import killall

killall()

