from pyrascont import *

dir_nam = 'sim_complete'
dir_nam = 'sim_no002'

res_crop_list = cropsim(dir_nam)
print(res_crop_list)

